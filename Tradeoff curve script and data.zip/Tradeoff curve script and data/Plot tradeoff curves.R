# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  ---- Function to fit trade-off curve and calculate balance points ----
#  ----          By SEEC, University of Cape Town       ---- 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

rm(list = ls())

library(rgdal)
library(ggplot2)
library(dplyr)
library(sf)
library(rgeos)
library(maptools)
library(rgdal)
library(ggplot2)
library(dplyr)
library(adehabitatHR)
library(track2KBA) 
library(argosfilter)
library(geosphere)
library(raster)
library(rnaturalearth)
library(sf)
library(rgdal)
library(tidyr)
library(ggsn)
library(tidyverse)
library(cowplot)
library(ggpubr)


# Given a set of points 
#  (i) removes those that are inside the convex hull, 
#  (ii) fits a spline to the remaining points
#  (iii) estimates the point where the derivative of the spline function is one
# It is crucial that both (0,0) and (1,1) are in the set of points
# then the Intermediate Value Theorem guarantees the existence of a point with
# derivative equal to one (and a unique such point if the curve is convex)
# Practically, this means the *scale* for x and y needs to be correct - both
# must be on the scale of proportion

# Set colour and shape mappings for the closures
closure_colours <- c(
  "MIBA" = 'yellowgreen',
  "mIBA_ARS" = 'darkgreen',
  "DFFE" = 'darkblue',
  "Original_20km" = 'turquoise',
  "CAF" = 'maroon2',
  "Industry" = 'transparent',
  "Current" = 'darkorange'
)

closure_shapes <- c(
  "MIBA" = 22, 
  "mIBA_ARS" = 22, 
  "DFFE" = 22, 
  "Original_20km" = 22,
  "CAF" = 22,
  "Industry" = 1,
  "Current" = 22
)

# Plotting function 
tradeoff <- function(
    pts, 
    plot_spline = TRUE, 
    spline_method = "monoH.FC",
    show_deriv_value = TRUE,
    add_ellipse = FALSE,
    colour_values = closure_colours,
    shape_values = closure_shapes,
    show_legend = TRUE
) {
  # check that both x and y are bounded by, and span [0,1]
  # stopifnot( min(pts$y)==0 & max(pts$y)==1 & min(pts$x)==0 & max(pts$x)==1 )
  
  # filter out points not on the convex hull
  pts_chull <- pts %>%
    filter( row_number() %in% chull(pts$x, pts$y) )
  
  # plot points, tradeoff curve and 'fair' point
  plot <- ggplot() +
    geom_point(
      data = pts, 
      mapping = aes(x=x, y=y, colour = Closure, shape = Closure), size = 6, alpha=0.8, fill = 'transparent', stroke=2
    ) +
    scale_colour_manual( values = closure_colours,
                       labels = c("MIBA" = "Foraging range (mIBA-UD90)", 
                                  "mIBA_ARS" = "Core foraging area (mIBA-ARS)", 
                                  "DFFE" = "DFFE (2021)", 
                                  "CAF" = "CAF",
                                  "Original_20km" = "20 km", 
                                  "Industry" = "Industry")) +
    scale_shape_manual( values = closure_shapes,
                        labels = c("MIBA" = "Foraging range (mIBA-UD90)", 
                                   "mIBA_ARS" = "Core foraging area (mIBA-ARS)", 
                                   "DFFE" = "DFFE (2021)", 
                                   "CAF" = "CAF",
                                   "Original_20km" = "20 km", 
                                   "Industry" = "Industry")) +
    coord_cartesian(xlim=c(0,1), ylim=c(0,NA)) +
    theme_classic()+
    theme(
      panel.grid.major = element_line(),
      aspect.ratio = 1,
      axis.text = element_text(size=15),
      axis.title = element_text(size=15),
      legend.text = element_text(size=15),
      legend.title = element_blank()
      #legend.position = 'none'
    ) +
    xlab(bquote('Penguin utility score ('* 'U' [R]*')')) +
    ylab("Estimated fishery catch loss")
  
  if (show_legend==FALSE) {
    plot <- plot + theme(legend.position = "none")
  }
  
  if (plot_spline) {
    # fit spline
    sp <- splinefun( pts_chull$x, pts_chull$y, method = spline_method )
    sp_vals <- tibble(
      x = seq(0,1,length.out=5001),
      y = sp(seq(0,1,length.out=5001)) 
    )
    
    # estimate derivatives with differences
    sp_diff <- diff(sp_vals$y) / diff(sp_vals$x)[1]
    i <- which(abs(sp_diff - 1) == min(abs(sp_diff - 1)))
    fair <- list(x=sp_vals$x[i], y=sp_vals$y[i])
    msg <- str_c("Derivative value = ", round(sp_diff[i],2))
    
    plot <- plot +
      geom_line( data = sp_vals, aes(x=x, y=y), alpha = 0.8 ) +
      geom_point(data=as_tibble(fair), aes(x=x, y=y), colour = "black", fill = 'yellow', size = 4, shape=21)
    
    if (show_deriv_value) {
      plot <- plot + 
        annotate( "text", x = 0.3, y = 0.5*max(sp_vals$y), label = msg)
    }
    
    # add ellipse
    if (add_ellipse) {
      get_ellipse <- function(x0, y0, r1, r2, theta) {
        tibble(
          t = seq(0, 2*pi, length.out = 100),
          x = x0 + r1 * cos(t) * cos(theta) - r2 * sin(t) * sin(theta),
          y = y0 + r1 * cos(t) * sin(theta) + r2 * sin(t) * cos(theta)
        )
      }
      
      plot <- plot +
        geom_polygon(
          data = get_ellipse(fair$x, fair$y, 0.1, 0.05, pi/4),
          mapping = aes(x=x,y=y),
          fill = "red",
          alpha = 0.2
        )
    }
  }
  
  # create list to return
  if (!plot_spline) {
    out <- list(plot = plot)
  } else {
    out <- list(plot = plot, fair = fair, sp_diff = sp_diff )
  }
  out
}

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   ---- Code for local/regional/national catch data plots ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# load data on local and regional catch totals
catch_data <- read.csv("C:\\Users\\elwei\\OneDrive - BirdLife South Africa\\Coastal Seabirds Working docs\\Projects\\Closures2024\\Marine policy paper on island closure extents\\Code and data for Dryad upload\\Tradeoff curve script and data\\Cost_UD90.csv") %>% as_tibble()
#CHANGE


# here Catch_loss_zeroed = Perc_loss * Regional_catch / 100
# catch_data %>%
#   mutate( Local_catch = Perc_loss * Regional_catch / 100, .after = Catch_loss_zeroed )

# remove variables we don't need and rename the ones we do
catch_data <- catch_data %>%
  filter( Error == "No" ) %>%
  dplyr::select( Island, Fish_type, Catch_loss_zeroed, Regional_catch ) %>%
  rename( 
    Local = Catch_loss_zeroed,
    Regional = Regional_catch
  )

# average national fish over 2011-2020 from the 'Historical catch totals' sheet 
# of "data/Small Pelagic Catch 2023_ up to 26042023.xlsx"
national_catch <- tibble(
  Fish_type = c("Anchovy", "Directed sardine", "Bycatch sardine", "Redeye"),
  National = c( 216082, 59246, 10076, 47342 )
)

# add national data to local and regional data
catch_data <- left_join( catch_data, national_catch, by = "Fish_type" )

# add catch on kilotonnes scale (kt) 
catch_data <- catch_data %>%
  mutate(
    Local_kt = signif( Local / 1000, 2),
    Regional_kt = signif( Regional / 1000, 2),
    National_kt = signif( National / 1000, 2)
  )

#write.csv(catch_data, "C:\\Users\\elwei\\OneDrive - BirdLife South Africa\\Coastal Seabirds Working docs\\Projects\\Closures2024\\Marine policy paper on island closure extents\\Tradeoff curves\\R outputs\\For Murray\\Estimated fish loss data_v2.csv")

# set colours for plotting
catch_colours <- 
  list( 
    "Local" = "grey40",
    "Regional" = "grey60",
    "National" = "grey80"
  )

# function to plot barplot of catch data
get_catch_barplot <- function(
    Isl,  
    Fish, 
    pts,   # from get_pts(Isl, Fish)
    dat = catch_data, 
    bar_cols = catch_colours,
    text_size = 5,
    pref = preferred_closures,
    closure_cols = closure_colours
) {
  # filter catch data to island and fish type
  dat <- dat %>%
    filter( Island == Isl, Fish_type == Fish )
  
  # preferred closure for given island
  pref_closure <- filter(pref, Island == Isl)$Closure
  
  # estimated catch loss for the preferred closure as proportion of local total
  catch_loss_pref_closure <- filter(pts, Closure == pref_closure)$y
  
  # add to dat
  dat <- dat %>%
    add_column("Closure" = catch_loss_pref_closure* dat$Local ) %>%
    mutate("Closure_kt" = signif( Closure / 1000, 2) )
  
  # format for plotting
  plot_dat <- dat %>%
    filter( Island == Isl, Fish_type == Fish ) %>%
    dplyr::select("Closure", "Local", "Regional", "National") %>%
    pivot_longer( everything() ) %>%
    mutate( name = factor(name, levels=c("Closure", "Local","Regional","National")) )
  plot_dat
  
  # add preferred closure colour to bar colours
  bar_cols <- c(bar_cols, "Closure" = closure_cols[[pref_closure]])
  
  # plot
  plot_dat %>%
    ggplot() +
    geom_col( aes(x = value, y = name, fill = name) ) +
    scale_fill_manual( values = bar_cols ) +
    theme_minimal() +
    theme(
      panel.grid = element_blank(),
      axis.title = element_blank(),
      axis.text = element_blank(),
      legend.position = "none",
    ) +
    annotate("text", x = dat$National, y = 4, hjust = 1.5,
             label = str_c( dat$National_kt," kt"), size = text_size ) +
    annotate("text", x = dat$Regional, y = 3, 
             hjust = ifelse(dat$Regional < 0.5*dat$National, -0.3, 1.5),
             label = str_c( dat$Regional_kt," kt"), size = text_size ) +
    annotate("text", x = dat$Local, y = 2, hjust = -0.3, 
             label = str_c( dat$Local_kt," kt"), size = text_size ) +
    annotate("text", x = dat$Local, y = 1, hjust = -0.3, 
             label = str_c( dat$Closure_kt," kt"), size = text_size )
}

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#             ---- Preferred closures at each colony ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

preferred_closures <- tibble(
  Island = c("Dassen", "Robben", "Stony Point", "Dyer", "St Croix", "Bird"),
  Closure = c("mIBA_ARS", "mIBA_ARS","mIBA_ARS","DFFE","DFFE","Original_20km")
)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#       ---- Load cost-benefit data and create auxiliary function ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

tradeoff_data <- read.csv("C:\\Users\\elwei\\OneDrive - BirdLife South Africa\\Coastal Seabirds Working docs\\Projects\\Closures2024\\Marine policy paper on island closure extents\\Code and data for Dryad upload\\Tradeoff curve script and data\\Tradeoff_curve_data.csv") %>%
  as_tibble() 


# remove points in error
tradeoff_data <- filter( tradeoff_data, Error == "No" )

#make industry values zero
tradeoff_data <- tradeoff_data %>% mutate(Perc_loss = ifelse(Closure == "Industry", 0, Perc_loss))
tradeoff_data <- tradeoff_data %>% mutate(Ur = ifelse(Closure == "Industry", 0, Ur))

# function to extract the closure information for a given island and fish type
get_pts <- function(Isl, Fish, to_dat = tradeoff_data) {
  pts <- to_dat %>%
    filter( 
      Island == Isl,
      Fish_type == Fish
    ) %>%
    dplyr::select( Closure, Ur, Perc_loss ) %>%
    mutate( prop_loss = Perc_loss / max(Perc_loss) ) %>%
    dplyr::select( - "Perc_loss" ) %>%
    rename( x = "Ur", y = "prop_loss" )
  
  pts
}

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                     ---- Dassen Island ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#------------
# anchovy
#------------

dassen_anch_pts <- get_pts("Dassen", "Anchovy") %>% 
  mutate(Closure = factor(Closure, 
                          levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry"))) %>% 
  mutate(Closure = if_else(Closure == "DFFE", "Current", Closure))
  
dassen_anch_to <- tradeoff( dassen_anch_pts, show_deriv_value = F )
# dassen_anch_to <- tradeoff( dassen_anch_pts, add_ellipse = TRUE) # to illustrate uncertainty in balance point
dassen_anch_inset <- get_catch_barplot("Dassen", "Anchovy", dassen_anch_pts)

#with barplots
dassen_anch_plot <- ggdraw(dassen_anch_to$plot + labs(title = "Anchovy") + 
                             theme(plot.title = element_text(size=15), legend.position = "bottom")) +
  draw_plot(dassen_anch_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)

dassen_anch_plot 

#------------
# directed sardine
#------------

dassen_sard_pts <- get_pts("Dassen", "Directed sardine") %>% 
  mutate(Closure = factor(Closure, 
                          levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry"))) %>% 
  mutate(Closure = if_else(Closure == "DFFE", "Current", Closure))

dassen_sard_to <- tradeoff( dassen_sard_pts, show_deriv_value = F )
dassen_sard_inset <- get_catch_barplot("Dassen", "Directed sardine", dassen_sard_pts)

# With barplots
dassen_sard_plot <- ggdraw(dassen_sard_to$plot+ labs(title = "Directed sardine") + 
                             theme(plot.title = element_text(size=15), legend.position = "none")) +
  draw_plot(dassen_sard_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)

dassen_sard_plot


#------------
# redeye
#------------

dassen_redeye_pts <- get_pts("Dassen", "Redeye") %>% 
  mutate(Closure = factor(Closure, 
                          levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry"))) %>% 
  mutate(Closure = if_else(Closure == "DFFE", "Current", Closure))

dassen_redeye_to <- tradeoff( dassen_redeye_pts, show_deriv_value = F )
dassen_redeye_inset <- get_catch_barplot("Dassen", "Redeye", dassen_redeye_pts)


# With barplot
dassen_redeye_plot <- ggdraw(dassen_redeye_to$plot+ labs(title = "Redeye") + 
                               theme(plot.title = element_text(size=15), legend.position = "none")) +
  draw_plot(dassen_redeye_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
dassen_redeye_plot 


#------------
# SAVE
#------------
das.t <- 
  ggarrange( dassen_anch_plot, dassen_sard_plot, dassen_redeye_plot,
           ncol = 2,
           nrow = 2,
           #align = "h",
           #labels = list("Anchovy", "Directed sardine", "Redeye", "Bycatch sardine"),
           #vjust = 3, #move label vertically
           #hjust = -0.5, #move label horizontally
           #font.label = list(size=16), #adjust size of label
           common.legend = TRUE,
           legend = 'none')


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                     ---- Robben Island ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#------------
# anchovy
#------------

robben_anch_pts <- get_pts("Robben", "Anchovy") %>%
  add_row(Closure = "Industry", x = 0, y = 0) %>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry"))) %>% 
  mutate(Closure = if_else(Closure == "DFFE", "Current", Closure))


robben_anch_to <- tradeoff( robben_anch_pts, show_deriv_value = F )
robben_anch_inset <- get_catch_barplot("Robben", "Anchovy", robben_anch_pts)

# With barplot
robben_anch_plot <- ggdraw(robben_anch_to$plot+ labs(title = "Anchovy") + theme(plot.title = element_text(size=20), legend.position = "none")) +
  draw_plot(robben_anch_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
robben_anch_plot

#------------
# directed sardine
#------------

robben_sard_pts <- get_pts("Robben", "Directed sardine") %>%
  add_row(Closure = "Industry", x = 0, y = 0) %>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))%>%
  mutate(Closure = if_else(Closure == "DFFE", "Current", Closure))

robben_sard_to <- tradeoff( robben_sard_pts, show_deriv_value = F )
robben_sard_inset <- get_catch_barplot("Robben", "Directed sardine", robben_sard_pts)

# With barplot
robben_sard_plot <- ggdraw(robben_sard_to$plot+ labs(title = "Directed sardine") + theme(plot.title = element_text(size=20), legend.position = "none")) +
  draw_plot(robben_sard_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
robben_sard_plot

#------------
# redeye
#------------

robben_redeye_pts <- get_pts("Robben", "Redeye") %>%
  add_row(Closure = "Industry", x = 0, y = 0) %>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))%>%   mutate(Closure = if_else(Closure == "DFFE", "Current", Closure))


robben_redeye_to <- tradeoff( robben_redeye_pts, show_deriv_value = F )
robben_redeye_inset <- get_catch_barplot("Robben", "Redeye", robben_redeye_pts)

# With barplot
robben_redeye_plot <- ggdraw(robben_redeye_to$plot+ labs(title = "Redeye") + theme(plot.title = element_text(size=20), legend.position = "none")) +
  draw_plot(robben_redeye_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
robben_redeye_plot

#------------
# SAVE
#------------

rob.t <- 
  ggarrange( robben_anch_plot, robben_sard_plot, robben_redeye_plot,
           ncol = 2,
           nrow = 2,
           #align = "h",
           #labels = list("Anchovy", "Directed sardine", "Redeye", "Bycatch sardine"),
           #vjust = 3, #move label vertically
           #hjust = -0.5, #move label horizontally
           #font.label = list(size=16), #adjust size of label
           common.legend = TRUE,
           legend = 'none')

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                     ---- Stony Point ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#------------
# anchovy
#------------

stony_anch_pts <- get_pts("Stony Point", "Anchovy") %>%
  add_row(Closure = "Industry", x = 0, y = 0) %>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))%>%   mutate(Closure = if_else(Closure == "CAF", "Current", Closure))

stony_anch_to <- tradeoff( stony_anch_pts, show_deriv_value = F )
stony_anch_inset <- get_catch_barplot("Stony Point", "Anchovy", stony_anch_pts)

# With barplot
stony_anch_plot <- ggdraw(stony_anch_to$plot+ labs(title = "Anchovy") + theme(plot.title = element_text(size=20), legend.position = "none")) +
  draw_plot(stony_anch_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
stony_anch_plot

#------------
# directed sardine
#------------

stony_sard_pts <- get_pts("Stony Point", "Directed sardine") %>%
  add_row(Closure = "Industry", x = 0, y = 0) %>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))%>%   mutate(Closure = if_else(Closure == "CAF", "Current", Closure))

stony_sard_to <- tradeoff( stony_sard_pts, show_deriv_value = F )
stony_sard_inset <- get_catch_barplot("Stony Point", "Directed sardine", stony_sard_pts)

# With barplot
stony_sard_plot <- ggdraw(stony_sard_to$plot+ labs(title = "Directed sardine") + theme(plot.title = element_text(size=20), legend.position = "none")) +
  draw_plot(stony_sard_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
stony_sard_plot

#------------
# redeye
#------------

stony_redeye_pts <- get_pts("Stony Point", "Redeye") %>%
  add_row(Closure = "Industry", x = 0, y = 0)%>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))%>%   mutate(Closure = if_else(Closure == "CAF", "Current", Closure))

stony_redeye_to <- tradeoff( stony_redeye_pts, show_deriv_value = F )
stony_redeye_inset <- get_catch_barplot("Stony Point", "Redeye", stony_redeye_pts)

# With barplot
stony_redeye_plot <- ggdraw(stony_redeye_to$plot+ labs(title = "Redeye") + theme(plot.title = element_text(size=20), legend.position = "none")) +
  draw_plot(stony_redeye_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
stony_redeye_plot

#------------
# bycatch sardine
#------------

stony_by_sard_pts <- get_pts("Stony Point", "Bycatch sardine") %>%
  add_row(Closure = "Industry", x = 0, y = 0)%>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))%>%   mutate(Closure = if_else(Closure == "CAF", "Current", Closure))

stony_by_sard_to <- tradeoff( stony_by_sard_pts, show_deriv_value = F )
stony_by_sard_inset <- get_catch_barplot("Stony Point", "Bycatch sardine", stony_by_sard_pts)

# With barplot
stony_by_sard_plot <- ggdraw(stony_by_sard_to$plot+ labs(title = "Bycatch sardine") + theme(plot.title = element_text(size=20), legend.position = "none")) +
  draw_plot(stony_by_sard_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
stony_by_sard_plot

#------------
# SAVE
#------------

stony.t <-
  ggarrange( stony_anch_plot, stony_sard_plot, stony_redeye_plot, stony_by_sard_plot,
           ncol = 2,
           nrow = 2,
           #align = "h",
           #labels = list("Anchovy", "Directed sardine", "Redeye", "Bycatch sardine"),
           #vjust = 3, #move label vertically
           #hjust = -0.5, #move label horizontally
           #font.label = list(size=16), #adjust size of label
           common.legend = TRUE,
           legend = 'none')

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                     ---- Dyer Island ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#------------
# anchovy
#------------

dyer_anch_pts <- get_pts("Dyer", "Anchovy") %>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))
dyer_anch_to <- tradeoff( dyer_anch_pts, show_deriv_value = F )
dyer_anch_inset <- get_catch_barplot("Dyer", "Anchovy", dyer_anch_pts)

# # With barplot
dyer_anch_plot <- ggdraw(dyer_anch_to$plot+ labs(title = "Anchovy") + theme(plot.title = element_text(size=20), legend.position = "none")+
                           geom_vline(xintercept =  0.3184372, linetype = "dashed", color = "darkorange", size=1)) +
  draw_plot(dyer_anch_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
dyer_anch_plot

#------------
# directed sardine
#------------

dyer_sard_pts <- get_pts("Dyer", "Directed sardine")  %>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))
dyer_sard_to <- tradeoff( dyer_sard_pts, show_deriv_value = F )
dyer_sard_inset <- get_catch_barplot("Dyer", "Directed sardine", dyer_sard_pts)

# # With barplot
dyer_sard_plot <- ggdraw(dyer_sard_to$plot+ labs(title = "Directed sardine") + theme(plot.title = element_text(size=20), legend.position = "none")+ geom_vline(xintercept =  0.3184372, linetype = "dashed", color = "darkorange", size=1)) +
  draw_plot(dyer_sard_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
dyer_sard_plot

#------------
# redeye
#------------

dyer_redeye_pts <- get_pts("Dyer", "Redeye") %>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))
dyer_redeye_to <- tradeoff( dyer_redeye_pts, show_deriv_value = F )
dyer_redeye_inset <- get_catch_barplot("Dyer", "Redeye", dyer_redeye_pts)

# # With barplot
dyer_redeye_plot <- ggdraw(dyer_redeye_to$plot+ labs(title = "Redeye") + theme(plot.title = element_text(size=20), legend.position = "none")+ geom_vline(xintercept =  0.3184372, linetype = "dashed", color = "darkorange", size=1)) +
  draw_plot(dyer_redeye_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
dyer_redeye_plot

#------------
# bycatch sardine
#------------

dyer_by_sard_pts <- get_pts("Dyer", "Bycatch sardine") %>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))
dyer_by_sard_to <- tradeoff( dyer_by_sard_pts, show_deriv_value = F )
dyer_by_sard_inset <- get_catch_barplot("Dyer", "Bycatch sardine", dyer_by_sard_pts)

# # With barplot
dyer_by_sard_plot <- ggdraw(dyer_by_sard_to$plot+ labs(title = "Bycatch sardine") + theme(plot.title = element_text(size=20), legend.position = "nonne")+ geom_vline(xintercept =  0.3184372, linetype = "dashed", color = "darkorange", size=1)) +
  draw_plot(dyer_by_sard_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
dyer_by_sard_plot

#------------
# SAVE
#------------

dyer.t <- 
  ggarrange( dyer_anch_plot, dyer_sard_plot, dyer_redeye_plot, dyer_by_sard_plot,
           ncol = 2,
           nrow = 2,
           #align = "h",
           #labels = list("Anchovy", "Directed sardine", "Redeye", "Bycatch sardine"),
           #vjust = 3, #move label vertically
           #hjust = -0.5, #move label horizontally
           #font.label = list(size=16), #adjust size of label
           common.legend = TRUE,
           legend = 'none')

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                     ---- St Croix ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# There is only directed sardine to consider at St Croix.

#------------
# directed sardine
#------------

stcroix_sard_pts <- get_pts("St Croix", "Directed sardine") %>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))
stcroix_sard_to <- tradeoff( stcroix_sard_pts, show_deriv_value = F )
stcroix_sard_inset <- get_catch_barplot("St Croix", "Directed sardine", stcroix_sard_pts)

# With barplots
stcroix_sard_plot <- stcroix_sard_to$plot +
  labs( title = "stcroix_directed sardine") +
  geom_vline(xintercept =  0.6065616, linetype = 'dashed', color = "darkorange", size=1)
stcroix_sard_plot <- ggdraw(stcroix_sard_plot+ labs(title = "Directed sardine") + theme(plot.title = element_text(size=20), legend.position = "none")) +
  draw_plot(stcroix_sard_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
stcroix_sard_plot

#------------
# SAVE
#------------
stc.t <- stcroix_sard_plot

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                     ---- Bird Island ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# There is only directed sardine to consider at Bird Island.

#------------
# directed sardine
#------------

bird_sard_pts <- get_pts("Bird", "Directed sardine") %>%
  add_row(Closure="Industry", x=0, y= 0) %>% 
  mutate( Closure = factor(Closure, levels=c("MIBA", "mIBA_ARS","DFFE","CAF", "Original_20km", "Industry")))%>%   mutate(Closure = if_else(Closure == "CAF", "Current", Closure))

bird_sard_to <- tradeoff( bird_sard_pts, show_deriv_value = F )
bird_sard_inset <- get_catch_barplot("Bird", "Directed sardine", bird_sard_pts)

# With barplot
bird_sard_plot <- bird_sard_to$plot +
  labs( title = "bird_directed sardine")
bird_sard_plot <- ggdraw(bird_sard_plot+ labs(title = "Directed sardine") + theme(plot.title = element_text(size=20), legend.position = "none")) +
  draw_plot(bird_sard_inset, x = 0.2, y = 0.5, width = 0.3, height = 0.3)
bird_sard_plot

#------------
# SAVE
#------------

bird.t <- bird_sard_plot

