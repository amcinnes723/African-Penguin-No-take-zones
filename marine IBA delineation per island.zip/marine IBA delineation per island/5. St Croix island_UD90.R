#---------------------------------------------------------------------

# Code to find foraging range of African penguins (mIBA-UD90)
# St Croix Island
# By BirdLife South Africa

# Cleaned tracking data can be requested from the BirdLife International
# Seabird Tracking Database (substitute input file for XXX once received):
# https://data.seabirdtracking.org/index.php/dataset/2215

#---------------------------------------------------------------------


#Load libraries

rm(list=ls())

library(adehabitatLT)
library(adehabitatHR)
library(geosphere)
library(track2KBA)
library(dplyr)
library(argosfilter)
library(raster)
library(rnaturalearth)
library(sf)
library(maptools)
library(rgdal)
library(tidyr)
library(lubridate)
library(lwgeom)
library(smoothr)
library(rgeos)
library(fields)
library(ggplot2)

#Read in data
setwd('XXX') #CHANGE

df <- read.csv('XXX') #CHANGE


## Use 7km for smoothing (h) parameter following Dias et al. 2018
h = 7
ud=90

df$datetime <- as.POSIXct(df$datetime,origin='1970-01-01')
head(df)
unique(df$BirdID)
tracks_formatted <- formatFields(
  dataGroup = df,
  fieldID   = "BirdID",
  fieldLat  ="latitude",
  fieldLon  ="longitude",
  fieldDateTime ="datetime")

#project tracks 
tracks_prj <- projectTracks(
  tracks_formatted, 
  projType = "azim", 
  custom = "TRUE"
)

# calculate mIBA ----------------------------------------------------------

#Colony location
colony <- data.frame(Colony = "St Croix Island",Longitude = 25.770118, Latitude  =-33.799579)
estSpaceUse2 <- function(
    tracks, scale, levelUD, res=NULL, polyOut=FALSE) {
  
  # check for duplicated data
  dup_check <- tracks@data %>% 
    group_by(.data$ID) %>%
    mutate(duplicates = duplicated(.data$DateTime)) %>% 
    ungroup() %>%
    dplyr::summarise(duplicates = sum(.data$duplicates))
  
  if (dup_check$duplicates > 0) {message(
    "WARNING:dataset may contain duplicated data, this will affect KDE"
  )}
  
  tracks@data <- tracks@data %>% dplyr::select(.data$ID)
  
  ### REMOVING IDs WITH TOO FEW LOCATIONS -------------------------------------
  
  validIDs <- names(which(table(tracks$ID) > 5))
  if (length(validIDs) == 0) {
    stop("No IDs have enough points (5) for KDE")
  } else if (length(validIDs) < n_distinct(tracks$ID)) {
    message(
      paste0("Following ID(s) have too few points for KDE: ",
             unique(tracks$ID)[!unique(tracks$ID) %in% validIDs])
    )
  }
  tracks <- tracks[(tracks@data$ID %in% validIDs), ]
  tracks@data$ID <- droplevels(as.factor(tracks@data$ID))
  
  ### SETTING PARAMETERS FOR kernelUD -----------------------------------------
  
  ### CREATE CUSTOM GRID for kernelUD (instead of same4all=TRUE) --------------
  d <- extent(tracks)
  ext <- extent(d@xmin-50000, d@xmax+50000, d@ymin-50000,d@ymax+50000 )
  rt1 <- raster(ext = ext, crs =proj4string(tracks), res = 500)
  INPUTgrid <- as(rt1, "SpatialPixelsDataFrame")
  
  
  ### ESTIMATING KERNEL DISTRIBUTION  -----------------------------------------
  KDE.Surface <- adehabitatHR::kernelUD(
    tracks, h = (scale * 1000), grid = INPUTgrid, same4all = FALSE
  )
  
  ###### OPTIONAL POLYGON OUTPUT ----------------------------------------------
  if (polyOut == TRUE) {
    if (!(levelUD >= 1 & levelUD <= 100)) {
      stop("levelUD must be between 1-100%")
    }
    tryCatch({
      KDE_sp <- adehabitatHR::getverticeshr(
        KDE.Surface, percent = levelUD, unin = "m", unout = "km2"
      )
    }, error = function(e) {
      sprintf("Providing individual home range polygons at a UD level of %s
          percent failed with the following error message: %s. This means that
          there was estimated space use that extended beyond the grid used for
          estimating the kernel density. To resolve this, use a lower UD level,
          or a smaller scale parameter.", levelUD,conditionMessage(e))
    }
    )
    
    if (("KDE_sp" %in% ls())) { ## PROCEED ONLY IF KDE successful
      
      KDE_sf <- st_as_sf(KDE_sp) %>%
        st_transform(4326) ### convert to longlat CRS
      
      return(list(KDE.Surface = KDE.Surface, UDPolygons = KDE_sf))
      
    } else {
      warning(
        sprintf("Providing individual home range polygons at a UD
              level of %s percent failed. This often means that there was
              estimated space use that extended beyond the grid used for
              estimating the kernel density. To resolve this, use a lower UD
              level, a smaller scale parameter, or a smaller size of grid cells
              (smaller 'res'). However, the same error may occur if your scale
              parameter is very small (compared to 'res'), because the grid is
              extended beyond the bounding box of locations by a distance of
              2*scale - and with a very small scale parameter that may not
              actually encompass a full grid cell. ", levelUD),
        immediate. = TRUE)
      return(KDE.Surface)
    }
    
  } else {
    return(KDE.Surface)
  }
}
#Calculate core kernels for each individual
KDE <- estSpaceUse2(
  tracks = tracks_prj, 
  scale = h,
  res= 0.5,
  levelUD = ud,
  polyOut = TRUE
)

#plot individual kernels
jpeg('/Plots/KDE_h7_SC_90ud.jpeg', units="in", width=6,height=6, res=1000) #CHANGE

mapKDE(KDE = KDE$UDPolygons, colony = colony)
dev.off()

#Assess how representative your results are 
jpeg('/Plots/samplerep_h7_SC_90ud.jpeg', units="in", width=6,height=6, res=1000) #CHANGE

repr <- repAssess(
  tracks    = tracks_prj, 
  KDE       = KDE$KDE.Surface, 
  levelUD = ud,
  iteration = 100, 
  bootTable = FALSE)

dev.off()

#Find mIBA
Site <- findSite(
  KDE = KDE$KDE.Surface,
  represent = repr$out,
  levelUD = ud,
  polyOut = TRUE, #if False you get gridded data
  popSize = 22110 #breeding pairs (median of population estimate 2008 - 2019 = 6824) * 3.24 following Crawford & Boonstra (1994)
)

sf_use_s2(FALSE) ## may need to be set in order for mapSite to work
Sitemap <- mapSite(Site, colony = colony)

plot(Site)

potSitearea <- Site %>% group_by(.data$potentialSite) %>% 
  summarise(N_animals = max(.data$N_animals)) %>% 
  filter(.data$potentialSite==TRUE)
d <- as_Spatial(potSitearea)
plot(d)

proj4string(d) <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")

###for multiple polygons
#See Handley et al 2020 and Lascelles et al 2016. You can drop all polygons and fill holes which have an area that is smaller that 5% of 
#the largest polygon

area_thresh <-  units::set_units((raster::area(d)*0.05)/1e6, km^2)
p_dropped <- drop_crumbs(d, threshold = area_thresh)

#fill wholes
p_dropped <- fill_holes(p_dropped, threshold = area_thresh)
par(mfrow=c(1,2))
plot(d, col = "black", main = "Original")
plot(p_dropped, col = "black", main = "After")
d <- p_dropped
par(mfrow=c(1,1))
#See if you can group polygons - you can group polygon which have centroid that are closer
#than 5% of the furthest distance 

d <- ggplot2::fortify(d)
head(d)
fin <- as.data.frame(matrix(ncol=3))
colnames(fin) <- c('x','y','piece')
for(p in 1:length(unique(d$piece))){
  temp <- d[d$piece == p,]
  f <- cbind(temp$long,temp$lat)
  f <- Polygon(f)
  f <- Polygons(list(f),1)
  f = SpatialPolygons(list(f))
  proj4string(f) <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
  cent <- as(gCentroid(f, byid = TRUE),'data.frame')
  cent$piece <- p
  fin <- rbind(fin,cent)
}
fin <- fin[-1,]

dis <- rdist.earth(fin[,c(1,2)])
dis[dis<max(dis)*0.05]
dis


#The last step is to make a MCP around the polygon. This polygon is your new MIBA
d <- ggplot2::fortify(d)
id <- unique(d$piece)
i=1
fin <- as.data.frame(matrix(ncol = 7))
colnames(fin) <- c("long",  "lat",   "order", "hole",  "piece", "id", "group")

for(i in 1:length(id)){
  temp <- d[d$piece == id[i],]
  coordinates(temp) <- ~long+lat
  proj4string(temp) <- CRS('+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs')
  new <- mcp(temp,percent = 100)
  plot(new)
  new <- ggplot2::fortify(new)
  new$piece <- i
  new$group <- i
  fin <- rbind(fin,new)}
fin <- fin[-1,]
Site <- Site[Site$N_animals >0,]

land <- readOGR('XXX') #CHANGE

##plot for MIBA and population representation stats
jpeg('/Plots/AP_h7_SC_90ud.jpeg',
     units="in", width=6,height=6, res=1000) #CHANGE

ggplot() +
  geom_sf(data=Site,mapping = aes(fill=N_animals, colour=N_animals)) +
  geom_polygon(data=new,aes(long,lat,group=group),fill='transparent',col='red')+
  geom_polygon(data=land,aes(long,lat,group=group),fill='grey90')+
  geom_point(data=colony,aes(Longitude,Latitude),colour='white',fill='white',size=1.5,stroke=1)+
  coord_sf(xlim = c(min(d$long)-0.3, max(d$long)+0.3 ), 
           ylim = c(min(d$lat)-0.3, max(d$lat)+0.3))+
  scale_fill_continuous(high = "#132B43", low = "#56B1F7") +
  scale_colour_continuous(high = "#132B43", low = "#56B1F7") + 
  theme_bw() +
  annotate('text',label=expression(underline('MIBA: African Penguin - St Croix Island')),x=mean(d$long),y=-33.5)+
  annotate('text',label='Representativeness',x=mean(d$long),y=-33.55)+
  annotate('text',label=paste0('of tracking data = ',as.character(round(repr$out,2)),'%'),x=mean(d$long),y=-33.6)+
  ylab("Latitude") +  xlab("Longitude") + guides(colour=FALSE)
dev.off()
f <- cbind(new$long,new$lat)
f <- Polygon(f)
f <- Polygons(list(f),1)
f_anc = SpatialPolygons(list(f))
df <- as.data.frame(matrix(ncol=1,nrow = 1))
df[1,1] <- 1
proj4string(f_anc) <- CRS('+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs')
f <- SpatialPolygonsDataFrame(Sr = f_anc,df)

##write shape files
setwd('XXX') #CHANGE

rgdal::writeOGR(obj=f, dsn="MIBAshape", "MIBA_AP_h7_SC_90ud", driver="ESRI Shapefile",overwrite_layer = T)
saveRDS(Site,'site_AP_h7_SC_90ud.rds')
saveRDS(repr,'AP_h7_SC_repr_90ud.rds')
write.csv(d, "MIBA_AP_h7_SC_poly_90ud.csv",row.names = F)
write.csv(new, "MIBA_AP_h7_SC_MCP_90ud.csv",row.names = F)
