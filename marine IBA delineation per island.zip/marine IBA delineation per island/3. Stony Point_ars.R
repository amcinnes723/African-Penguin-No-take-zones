#---------------------------------------------------------------------

# Code to find core foraging areas of African penguins (mIBA-ARS)
# Stony Point
# By BirdLife South Africa

# Cleaned tracking data can be requested from the BirdLife International
# Seabird Tracking Database (substitute input file for XXX once received):
# https://data.seabirdtracking.org/index.php/dataset/2214

#---------------------------------------------------------------------


#Load libraries

rm(list=ls())

library(adehabitatLT)
library(adehabitatHR)
library(geosphere)
library(track2KBA)
library(dplyr)
library(argosfilter)
library(raster)
library(rnaturalearth)
library(sf)
library(maptools)
library(rgdal)
library(tidyr)
library(lubridate)
library(lwgeom)
library(smoothr)
library(rgeos)
library(fields)
library(ggplot2)

# Find Optimal Kernel Smoothing and Isopleth values -------------------------------------

#Read in data
df <- read.csv('XXX') ####CHANGE

#Find the Optimal isotpleth of the core foraging area for each individual following VanderWal and Rogers (2012)

core.area<-function(data, h, id){ # is the data with lat, lon and id; id is a vector with the ids you want to make KUDs for
  IVseq<-seq(0.01,0.90,0.01)#sequence of isopleth volumes
  data <- data[,c('longitude','latitude','track_id')]
  ## convert to SpatialPointsDataFrame and project
  coordinates(data) <- ~longitude + latitude
  proj4string(data) <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
  data <- spTransform(data, CRS="+proj=utm +zone=33 +datum=WGS84")
  
  d <- extent(data)
  ext <- extent(d@xmin-100000, d@xmax+100000, d@ymin-100000,d@ymax+100000 )
  rt1 <- raster(ext = ext, crs = "+proj=utm +zone=33 +datum=WGS84", res = 500)
  grid <- as(rt1, "SpatialPixelsDataFrame")
  
  kernel.areas<-as.data.frame(kernel.area(kernelUD(data, h=(h * 1000), grid=grid, extent=BExt),percent=c(1:90)))[,1]
  
  df<-as.data.frame(cbind(IVseq,kernel.areas/max(kernel.areas)))#create a dataframe with the percent area (PA) and isopleth volume (IV) scaled from 0-1
  colnames(df)<-c("IV","PA")#name the columns
  nls.fit<-nls(PA~(b0)*(exp(b1*IV)), data=df, start=list(b0=0.01, b1=6.2), na.action="na.omit", model=TRUE)#Caution: Starting parameters may differ for your data.
  b0<-summary(nls.fit)$coefficients[1,1]#b0 coefficient
  b1<-summary(nls.fit)$coefficients[2,1]#b0 coefficient
  (-log(b0*b1)/b1)#isopleth volume where the curve's slope = 1
}

## Find appropriate smoothing (h) parameter (see Lascelles et al. 2016)
#format tracks

df$datetime <- as.POSIXct(df$datetime,origin='1970-01-01')
head(df)
unique(df$BirdID)
tracks_formatted <- formatFields(
  dataGroup = df,
  fieldID   = "BirdID",
  fieldLat  ="latitude",
  fieldLon  ="longitude",
  fieldDateTime ="datetime")

#project tracks 
tracks_prj <- projectTracks(
  tracks_formatted, 
  projType = "azim", 
  custom = "TRUE"
)

#find median ARS scale
jpeg('XXX/ARS_SP.jpeg',
     units="in", width=6,height=6, res=1000) #CHANGE
h_vals <- findScale(tracks_prj, scaleARS = TRUE) #scaleARS (smoothing parameter, h)
dev.off()

h<-h_vals[1,5]
## utilisation distributions for each id for different method using core.area function
id <- unique(df$track_id)
fin <- as.data.frame(matrix(ncol=2,nrow=length(id)))
colnames(fin) <- c('id','ca')
for(i in 1:length(id)) {
  temp <- df[df$track_id == id[i], ]
  fin$ca[i] <- core.area(temp,h=h) #value taken from ARS value
  fin$id[i] <- as.character(id[i])
}
fin  
hist(fin$ca)
fin$ca <- fin$ca*100
final <- cbind(island='StonyPoint',median=round(median(fin$ca),1),
               mean=round(mean(fin$ca),1),sd=round(sd(fin$ca),1),
               range1=round(range(fin$ca)[1],1),rangge2=round(range(fin$ca)[2],1))
ud <- as.numeric(final[1,2])
ud <- round(ud,digits=0)#value from optimal ispoleth value selection

write.csv(final,'XXX/coreareaisopleth_SP.csv',row.names = F) #CHANGE


# calculate mIBA ----------------------------------------------------------

#Colony location
colony <- data.frame(Colony = "Stony Point",Longitude = 18.89467, Latitude  =-34.373437)

#Calculate core kernels for each individual
KDE <- estSpaceUse(
  tracks = tracks_prj, 
  scale = h,
  res= 0.5,
  levelUD = ud,
  polyOut = TRUE
)

#plot individual kernels
jpeg('XXX/KDE_SP.jpeg',
     units="in", width=6,height=6, res=1000) #CHANGE
mapKDE(KDE = KDE$UDPolygons, colony = colony)
dev.off()

#Assess how representative your results are 
jpeg('XXX/samplerep_SP.jpeg',
     units="in", width=6,height=6, res=1000) #CHANGE
repr <- repAssess(
  tracks    = tracks_prj, 
  KDE       = KDE$KDE.Surface, 
  levelUD = ud,
  iteration = 100, 
  bootTable = FALSE)
dev.off()

#Find mIBA
Site <- findSite(
  KDE = KDE$KDE.Surface,
  represent = repr$out,
  levelUD = ud,
  polyOut = TRUE, #if False you get gridded data
  popSize = 5748 #breeding pairs (median of population estimate 2008 - 2019 = 2140) * 3.24 following Crawford & Boonstra (1994)
)

sf_use_s2(FALSE)
Sitemap <- mapSite(Site, colony = colony)

plot(Site)

potSitearea <- Site %>% group_by(.data$potentialSite) %>% 
  summarise(N_animals = max(.data$N_animals)) %>% 
  filter(.data$potentialSite==TRUE)
d <- as_Spatial(potSitearea)
plot(d)


proj4string(d) <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")

###for multiple polygons
#See Handley et al 2020 and Lascelles et al 2016. You can drop all polygons and fill holes which have an area that is smaller that 5% of 
#the largest polygon


area_thresh <-  units::set_units((raster::area(d)*0.05)/1e6, km^2) 
p_dropped <- drop_crumbs(d, threshold = area_thresh)
#fill wholes
p_dropped <- fill_holes(p_dropped, threshold = area_thresh)
par(mfrow=c(1,2))
plot(d, col = "black", main = "Original")
plot(p_dropped, col = "black", main = "After")
d <- p_dropped
par(mfrow=c(1,1))

#See if you can group polygons - you can group polygon which have centroid that are closer
#than 5% of the furthest distance 

d <- ggplot2::fortify(d)
head(d)
fin <- as.data.frame(matrix(ncol=3))
colnames(fin) <- c('x','y','piece')
for(p in 1:length(unique(d$piece))){
  temp <- d[d$piece == p,]
  f <- cbind(temp$long,temp$lat)
  f <- Polygon(f)
  f <- Polygons(list(f),1)
  f = SpatialPolygons(list(f))
  proj4string(f) <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
  cent <- as(gCentroid(f, byid = TRUE),'data.frame')
  cent$piece <- p
  fin <- rbind(fin,cent)
}
fin <- fin[-1,]

dis <- rdist.earth(fin[,c(1,2)])
dis[dis<max(dis)*0.05]
dis
#So no polygons need to be merged here

#The last step is to make a MCP around the polygon. This polygon is your new MIBA
d <- ggplot2::fortify(d)
id <- unique(d$piece)
i=1
fin <- as.data.frame(matrix(ncol = 7))
colnames(fin) <- c("long",  "lat",   "order", "hole",  "piece", "id", "group")

for(i in 1:length(id)){
  temp <- d[d$piece == id[i],]
  coordinates(temp) <- ~long+lat
  proj4string(temp) <- CRS('+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs')
  new <- mcp(temp,percent = 100)
  plot(new)
  new <- ggplot2::fortify(new)
  new$piece <- i
  new$group <- i
  fin <- rbind(fin,new)}
fin <- fin[-1,]
Site <- Site[Site$N_animals >0,]
land <- readShapePoly("XXX/coast2.shp") #CHANGE

##plot for MIBA and population representation stats
jpeg('XXX/AP_SP.jpeg',
     units="in", width=6,height=6, res=1000) #CHANGE

ggplot() +
  geom_sf(data=Site,mapping = aes(fill=N_animals, colour=N_animals)) +
  geom_polygon(data=new,aes(long,lat,group=group),fill='transparent',col='red')+
  geom_polygon(data=land,aes(long,lat,group=group),fill='grey90')+
  geom_point(data=colony,aes(Longitude,Latitude),colour='white',fill='white',size=1.5,stroke=1)+
  coord_sf(xlim = c(min(d$long)-0.3, max(d$long)+0.3 ), 
           ylim = c(min(d$lat)-0.3, max(d$lat)+0.3))+
  scale_fill_continuous(high = "#132B43", low = "#56B1F7") +
  scale_colour_continuous(high = "#132B43", low = "#56B1F7") + 
  theme_bw() +
  annotate('text',label=expression(underline('MIBA: African Penguin - Stony Point')),x=mean(d$long)+0.2,y=-34.05)+
  annotate('text',label='Representativeness',x=mean(d$long)+0.2,y=-34.1)+
  annotate('text',label=paste0('of tracking data = ',as.character(round(repr$out,2)),'%'),x=mean(d$long)+0.2,y=-34.15)+
  ylab("Latitude") +  xlab("Longitude") + guides(colour=FALSE)
dev.off()
f <- cbind(new$long,new$lat)
f <- Polygon(f)
f <- Polygons(list(f),1)
f_anc = SpatialPolygons(list(f))
df <- as.data.frame(matrix(ncol=1,nrow = 1))
df[1,1] <- 1
proj4string(f_anc) <- CRS('+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs')
f <- SpatialPolygonsDataFrame(Sr = f_anc,df)

##write shape files
setwd('XXX/MIBAout/') #CHANGE

rgdal::writeOGR(obj=f, dsn="MIBAshape", "MIBA_AP_SP", driver="ESRI Shapefile",overwrite_layer = T)
saveRDS(Site,'site_AP_SP.rds')
saveRDS(repr,'AP_SP_repr.rds')
write.csv(d, "MIBA_AP_SP_poly.csv",row.names = F)
write.csv(new, "MIBA_AP_SP_MCP.csv",row.names = F)
